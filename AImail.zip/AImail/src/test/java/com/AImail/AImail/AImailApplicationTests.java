package com.AImail.AImail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AImailApplicationTests {

	@Test
	void contextLoads() {
	}

}
